API link
https://github.com/BoschSensortec/BME680_driver/releases

please use version v3.5.10